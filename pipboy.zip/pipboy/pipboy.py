import pygame, sys, json

pygame.init()
screen_info = pygame.display.Info()
screen_width, screen_height = screen_info.current_w, screen_info.current_h
screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)
pygame.display.set_caption("Pip-Boy 3000")
clock = pygame.time.Clock()

font = pygame.font.SysFont("Courier", 30, bold=True)

GREEN = (0, 255, 0)
DARK_GREEN = (0, 150, 0)
BLACK = (0, 0, 0)
HEADER_BG = (0, 50, 0)

tabs = ["STAT", "ITEM", "DATA", "MAP", "RADIO"]
current_tab = 0
inventory_scroll = 0

with open("player_data.json") as f:
    data = json.load(f)

map_image = pygame.image.load("map.png")
map_offset = [100, 150]  # Start map below header area by 150

map_dragging = False

HEADER_HEIGHT = 140  # Large header height to be safe

def draw_scanlines():
    for y in range(0, screen.get_height(), 4):
        pygame.draw.line(screen, DARK_GREEN, (0, y), (screen.get_width(), y))

def draw_tab_header():
    # Draw solid background for header
    pygame.draw.rect(screen, HEADER_BG, (0, 0, screen.get_width(), HEADER_HEIGHT))
    # Draw bright border below header to separate clearly
    pygame.draw.line(screen, GREEN, (0, HEADER_HEIGHT), (screen.get_width(), HEADER_HEIGHT), 3)

    title = font.render("Pip-Boy 3000", True, GREEN)
    screen.blit(title, (20, 20))

    for i, tab in enumerate(tabs):
        color = GREEN if i == current_tab else DARK_GREEN
        tab_text = font.render(tab, True, color)
        # Vertically center tabs inside header
        screen.blit(tab_text, (200 + i * 180, (HEADER_HEIGHT // 2) - (tab_text.get_height() // 2)))

def render_lines(lines, start_y):
    for i, line in enumerate(lines):
        text = font.render(line, True, GREEN)
        screen.blit(text, (50, start_y + i * 40))

def draw_content():
    # Force content start Y well below header
    content_start_y = HEADER_HEIGHT + 20

    if tabs[current_tab] == "STAT":
        render_lines([
            f"Name: {data['name']}",
            f"Level: {data['level']}",
            f"HP: {data['hp']}",
            f"RAD: {data['rad']}",
            f"XP: {data['xp']}"
        ], content_start_y)

    elif tabs[current_tab] == "ITEM":
        visible_items = data['inventory'][inventory_scroll:inventory_scroll + 10]
        render_lines(visible_items, content_start_y)

    elif tabs[current_tab] == "DATA":
        render_lines(data['quests'], content_start_y)

    elif tabs[current_tab] == "MAP":
        # Force map Y not to go above header bottom
        map_x, map_y = map_offset
        if map_y < HEADER_HEIGHT + 10:
            map_y = HEADER_HEIGHT + 10
        map_offset[1] = map_y

        screen.blit(map_image, (map_x, map_y))
        pygame.draw.rect(screen, GREEN, (map_x, map_y, map_image.get_width(), map_image.get_height()), 2)

    elif tabs[current_tab] == "RADIO":
        render_lines([data['radio']], content_start_y)

    screen.blit(font.render("← / → to switch tabs | Scroll / drag to navigate | Esc to quit", True, GREEN),
                (50, screen.get_height() - 50))

while True:
    screen.fill(BLACK)
    draw_tab_header()
    draw_content()
    draw_scanlines()
    pygame.display.flip()
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
            pygame.quit()
            sys.exit()

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                current_tab = (current_tab + 1) % len(tabs)
            elif event.key == pygame.K_LEFT:
                current_tab = (current_tab - 1) % len(tabs)
            elif event.key == pygame.K_DOWN and tabs[current_tab] == "ITEM":
                inventory_scroll = min(inventory_scroll + 1, max(0, len(data['inventory']) - 10))
            elif event.key == pygame.K_UP and tabs[current_tab] == "ITEM":
                inventory_scroll = max(0, inventory_scroll - 1)

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 and tabs[current_tab] == "MAP":
                map_dragging = True
                mouse_start = event.pos
                map_start = map_offset[:]
            elif event.button == 4 and tabs[current_tab] == "ITEM":
                inventory_scroll = max(0, inventory_scroll - 1)
            elif event.button == 5 and tabs[current_tab] == "ITEM":
                inventory_scroll = min(inventory_scroll + 1, max(0, len(data['inventory']) - 10))

        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                map_dragging = False

        elif event.type == pygame.MOUSEMOTION:
            if map_dragging:
                dx = event.pos[0] - mouse_start[0]
                dy = event.pos[1] - mouse_start[1]
                map_offset = [map_start[0] + dx, map_start[1] + dy]

